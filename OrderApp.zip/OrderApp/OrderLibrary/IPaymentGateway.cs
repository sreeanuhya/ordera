﻿namespace OrderLibrary
{
    public interface IPaymentGateway
    {
        bool ChargePayment(string creditCardNumber, decimal amount);
    }
}
