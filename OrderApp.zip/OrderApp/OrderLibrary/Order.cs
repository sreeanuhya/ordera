﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Mail;

namespace OrderLibrary
{
    public class Order
    {
        public int Id { get; set; }
        public string ProductId { get; set; }
        public string CreditCardNumber { get; set; }
        public  decimal amount { get; set; }
        List<Product> lstproducts;
        public int Quantity { get; set; }
        public Order()
        {
            lstproducts = new List<Product>
        {
            new Product { Id=111,Name="Car",Quantity=30},
            new Product { Id=222,Name="Bike",Quantity=2},
            new Product { Id=333,Name="Cycle",Quantity=5},
            new Product { Id=444,Name="Scooty",Quantity=8},
        };
        }
        public bool  PlaceOrder(out string message)
        {
            message = "Successfully placed order";
            if (CheckInventory(this.ProductId, this.Quantity))
            {
                try
                {
                    IPaymentGateway paymentGateway = new PaymentGateway();
                    paymentGateway.ChargePayment(this.CreditCardNumber, this.amount);
                    Sendemail(this.Id);
                    return true;
                }
                catch (Exception)
                {
                    message = "Payment failed";
                    return false;
                }
               
            }
            else
            {
                message = "Invalid Quantity";
                return false;
            }
        }

       private  bool CheckInventory(string productId, int qty)
        {
            return lstproducts.Exists(p => p.Id == Convert.ToInt32(productId) && p.Quantity >= qty);
        }

       private bool Sendemail(int orderNumber)
        {
            bool isOnline = false;
            try
            {
                string emailbody = $" Please  ship the order {orderNumber}";
                var mailMessage = new MailMessage
                {
                    From = new MailAddress("abc@gmail.com"),
                    Subject = "subject",
                    Body = $"<h3>{emailbody}</h3>",
                    IsBodyHtml = true,
                };
                mailMessage.To.Add("shipping@gmail.com");

                var smtpClient = new SmtpClient("smtp.gmail.com")
                {
                    Port = 587,
                    Credentials = new NetworkCredential("xdy@gmail.com", "password"),
                    EnableSsl = true,
                };

                if(isOnline)
                smtpClient.Send(mailMessage);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
       
        }

    }

  
}
