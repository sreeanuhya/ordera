﻿namespace OrderLibrary
{
    public class PaymentGateway : IPaymentGateway
    {

        bool IPaymentGateway.ChargePayment(string creditCardNumber, decimal amount)
        {
            return true;
        }
    }
}
