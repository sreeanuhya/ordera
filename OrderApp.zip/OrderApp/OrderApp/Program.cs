﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderApp
{
    class Program
    {
        static void Main(string[] args)
        {
            OrderLibrary.Order order = new OrderLibrary.Order
            {
                ProductId = "111",
                Id = 123,
                Quantity = 5,
                CreditCardNumber = "1122"
            };
            string message;
            order.PlaceOrder(out message);
            Console.WriteLine(message);
            Console.ReadKey();
        }
    }
}
