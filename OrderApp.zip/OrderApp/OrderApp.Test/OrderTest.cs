using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace OrderApp.Test
{
    [TestClass]
    public class OrderTest
    {
        [TestMethod]
        public void PlacetheorderPositivequantity()
        {
            OrderLibrary.Order order = new OrderLibrary.Order
            {
                ProductId = "111",
                Id = 123,
                Quantity = 5,
                CreditCardNumber = "1122"
            };
            string message;
            var actualres=order.PlaceOrder(out message);
            Assert.AreEqual(true, actualres);
        }
        [TestMethod]
        public void PlacetheorderwithMorequantity()
        {
            OrderLibrary.Order order = new OrderLibrary.Order
            {
                ProductId = "111",
                Id = 123,
                Quantity = 95,
                CreditCardNumber = "1122"
            };
            string message;
            var actualres = order.PlaceOrder(out message);
            Assert.AreEqual(false, actualres);
        }

        [TestMethod]
        public void PlacetheorderwithInvalidproductid()
        {
            OrderLibrary.Order order = new OrderLibrary.Order
            {
                ProductId = "1667",
                Id = 123,
                Quantity = 95,
                CreditCardNumber = "1122"
            };
            string message;
            var actualres = order.PlaceOrder(out message);
            Assert.AreEqual(false, actualres);
        }

        [TestMethod]
        public void placeordercheckresultemessage()
        {
            OrderLibrary.Order order = new OrderLibrary.Order
            {
                ProductId = "111",
                Id = 123,
                Quantity = 5,
                CreditCardNumber = "1122"
            };
            string message;
            order.PlaceOrder(out message);
            var expecres = "Successfully placed order";
            Assert.AreEqual(expecres, message);
        }

        [TestMethod]
        public void placeorderchecknegresultemessage()
        {
            OrderLibrary.Order order = new OrderLibrary.Order
            {
                ProductId = "111",
                Id = 123,
                Quantity = 3335,
                CreditCardNumber = "1122"
            };
            string message;
            order.PlaceOrder(out message);
            var expecres = "Invalid Quantity";
            Assert.AreEqual(expecres, message);
        }

    }
}
